References 
1.	https://lhncbc.nlm.nih.gov/LHC-downloads/downloads.html#malaria-datasets
2.	https://en.wikipedia.org/wiki/Malaria
3.	https://keras.io/guides/sequential_model/
4.	https://www.kaggle.com/iarunava/cell-images-for-detecting-malaria
5.	https://keras.io/api/applications/vgg/
6.	https://www.mcgill.ca/chpi/centre/diseases
